<?php
   define('DB_SERVER', 'localhost:3306');
   define('DB_USERNAME', 'albhid4_albhid4');
   define('DB_PASSWORD', 'VR3G=XGBV#66');
   define('DB_DATABASE', 'albhid4_colegiodatabase');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>