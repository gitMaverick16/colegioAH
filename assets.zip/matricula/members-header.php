
  <link rel="icon" href="Logof.gif" type="image/gif" sizes="16x16">

<div class="col-sm-2">
         <img src="images/logo-institucion-alberto-hidalgo.png" alt="Logo colegio"     height="85";>
          <a href="https://www.albertohidalgo.edu.pe"></a>



</div>
<div class="col-sm-2">
</div>
<div class="col-sm-8">
 </div>
     <nav class="col-sm-2">
	 <div class="btn-group-vertical btn-group-sm" role="group" aria-label="Button Group">
</div>
    </nav>    
