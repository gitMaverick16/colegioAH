  <link rel="icon" href="Logof.gif" type="image/gif" sizes="16x16">

<div class="col-sm-2">
      <link rel="icon" href="Logof.gif" type="image/gif" sizes="16x16">

<img src="images/logo-institucion-alberto-hidalgo.png" alt="Logo colegio"  ;
          <a href="https://www.albertohidalgo.edu.pe"></a></div>
<div class="col-sm-8">
 <h1 class="blue-text mb-4 font-bold"></h1>
 </div>
     <nav class="col-sm-2">
	 <div class="btn-group-vertical btn-group-sm" role="group" aria-label="Button Group">

</div>
    </nav>